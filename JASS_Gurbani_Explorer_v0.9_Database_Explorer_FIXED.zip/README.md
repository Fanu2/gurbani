# JASS Gurbani Explorer v0.9

**Database Explorer • Search • Cohesive Context • Reader • Card Studio**

### v0.9 startup fix

Font detection is performed only after `QApplication` is created, preventing the `QFontDatabase: Must construct a QGuiApplication` startup warning.

v0.9 is an additive upgrade over the v0.8 stable base and is designed to work with `gurbani_v3.1_test.db`.

## Improvements

- v3.1 schema support: `corpus_meta`, `source_records`, `passages`, `lines`, `gurbani_fts`
- Predictable Unicode/Gurmukhi search
- Ang, Raag, author and stanza metadata
- Matched-only, local context, complete stanza and complete passage views
- Explicit Complete Passage action
- Existing Card Studio preserved
- Safe QImage-based card rendering and PNG export
- Random discovery
- Favorites
- Database chooser
- Dark/light theme

## Run

No separate virtual environment is required if PySide6 is installed globally.

```powershell
cd "C:\Users\singh\Downloads\JASS_Gurbani_Explorer_v0.9"
py .\JASS_Gurbani_Explorer_v0.9.py
```

Keep these together:

```text
JASS_Gurbani_Explorer_v0.9/
├── JASS_Gurbani_Explorer_v0.9.py
└── gurbani_v3.1_test.db
```

The application automatically prefers `gurbani_v3.1_test.db`.

## Database status

`gurbani_v3.1_test.db` is a working/test corpus database. It is not yet the final frozen `gurbani.db`.

The next corpus milestone is stronger reconstruction of:

```text
Ang
 ↓
Raag
 ↓
Mahalla / Author
 ↓
Shabad
 ↓
Stanza / Pauri
 ↓
Line
```

## Stability

v0.8 remains the protected foundation.

```text
v0.8 Stable Base
       ↓
v0.9 Database Integration
       ↓
v1.0 Corpus-Aware Explorer
       ↓
Future additive enhancements
```

Avoid unnecessary rewrites of working search, database loading, card rendering and preview architecture.

## Future v1.0

- Ang/Raag/Mahalla filters
- Shabad-aware grouping
- Exact passage boundaries
- Search highlighting
- Better ranking
- Source-page mapping
- Corpus quality dashboard
- Backup/restore
- More card templates
- Automatic font fitting
- Background images
- Batch cards
- JPG/PDF export
- SRT generation
- Quote-video preparation
